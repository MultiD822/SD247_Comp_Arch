/*I ran the gcc -Og -S addNumbers.c to get the assaly file and worked off of that
 - Programmer: Kai Schenkel
 - Class: SD-247 Computer Architecture
 - Data: 2/4/2024
 - Project 2: Assembly Programming
*/
int addNums(int a, int b)
{
    printf("Numbers going though the Addition Function\n");
    return a + b;
}